
Under debian install kodi 17 or above and python-libtorrent library

apt install kodi
apt install python-libtorrent

then create a zip from this content using :

./createaddon.sh

Then follow kodi https://kodi.wiki/view/Add-on_manager#How_to_install_from_a_ZIP_file from the created file.